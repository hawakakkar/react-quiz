function NextButton({ dispatch, answer, numQuestions, index }) {
  if (answer === null) return null;
  if (numQuestions > index + 1)
    return (
      <button
        className="btn btn-ui"
        onClick={() => dispatch({ type: "newQuestion" })}
      >
        Next
      </button>
    );
  if (numQuestions === index + 1)
    return (
      <button
        className="btn btn-ui"
        onClick={() => dispatch({ type: "finished" })}
      >
        Finish
      </button>
    );
}

export default NextButton;
