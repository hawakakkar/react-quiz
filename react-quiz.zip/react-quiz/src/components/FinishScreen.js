function FinishScreen({ points, maxPossiblePoints }) {
  const percentage = (points / maxPossiblePoints) * 100;

  return (
    <p className="result">
      you scored <strong>{points}</strong> out {maxPossiblePoints}
      {Math.ceil(percentage)}%
    </p>
  );
}
export default FinishScreen;
